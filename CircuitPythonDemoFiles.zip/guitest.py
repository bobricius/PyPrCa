import random
import time
import busio
import board
import displayio
import framebufferio
import os
import terminalio
from digitalio import DigitalInOut
import pwmio
from digitalio import DigitalInOut, Pull
from adafruit_button import Button
from picomputer import *
from adafruit_display_text import label
import adafruit_matrixkeypad
from adafruit_cursorcontrol.cursorcontrol import Cursor
import adafruit_imageload


#, board.IO3
#displayio.release_displays()
#SPI = busio.SPI(config.SPI_CLK, config.SPI_MOSI)
#display_bus = displayio.FourWire(SPI, command=config.TFT_DC, chip_select=config.TFT_CS)
#display = ST7789(display_bus, rotation=config.DISPLAY_ROTATION, width=config.DISPLAY_WIDTH, height=config.DISPLAY_HEIGHT, backlight_pin=config.BACKLIGHT)
# Make the display context
#display = config.display
# Create the display context
splash = displayio.Group()

# Use the built-in system font
font = terminalio.FONT

##########################################################################
# Make a background color fill

#color_bitmap = displayio.Bitmap(display.width, display.height, 1)
#color_palette = displayio.Palette(1)
#color_palette[0] = 0x404040
#bg_sprite = displayio.TileGrid(color_bitmap, pixel_shader=color_palette, x=0, y=0)
#splash.append(bg_sprite)

##########################################################################

bitmap, palette = adafruit_imageload.load("bmps/desktop.bmp",
                                          bitmap=displayio.Bitmap,
                                          palette=displayio.Palette)

# Create a TileGrid to hold the bitmap
tile_grid = displayio.TileGrid(bitmap, pixel_shader=palette)
splash.append(tile_grid)



# Create a text label
text_label = label.Label(
    font, text="CircuitPython Cursor!", color=0x00FF00, x=10, y=30
)
splash.append(text_label)

# Create a text label
text_label2 = label.Label(
    font, text="hello", color=0x000000, x=10, y=30
)
splash.append(text_label2)

# Create a text label
text_label3 = label.Label(
    font, text="Long \r \n text \r \n multiline", color=0xFFFF00, x=10, y=30
)
splash.append(text_label3)

my_button = Button(x=20, y=20, width=50, height=20,
                   label="OK", label_font=terminalio.FONT, style=Button.SHADOWROUNDRECT)

splash.append(my_button)
# initialize the mouse cursor object
mouse_cursor = Cursor(display, display_group=splash)

#cursor = mouse_cursor

display.show(splash)

prev_btn = None
x=100
y=100

while True:
#    cursor.update()
    keys=getKey(0)
    if keys:
        if keys == "lt":
            if x > 0:
                x = x - 2
        if keys == "rt":
            if x < 320:
                x = x + 2
        if keys == "up":
            if y > 0:
                y = y - 2
        if keys == "dn":
            if y < 240:
                y = y + 2
                
    text_label.text=str(x)+","+str(y)
    text_label.x=y
    text_label.y=x
    text_label2.x=x
    text_label3.y=y

    mouse_cursor.x=x
    mouse_cursor.y=y
    my_button.x=x+100
    my_button.y=y+100